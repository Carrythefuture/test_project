import styles from './Main.module.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';

const Main = () => {
    

    return (
        <div className={styles.container}>
            <h2>환영합니다!</h2>
            <div className={styles.btns}>
            <button>회원게시판</button><br />
            <button>마이페이지</button><br />
            <button>회원탈퇴</button><br />
            </div>
        </div>
    );
}

export default Main;